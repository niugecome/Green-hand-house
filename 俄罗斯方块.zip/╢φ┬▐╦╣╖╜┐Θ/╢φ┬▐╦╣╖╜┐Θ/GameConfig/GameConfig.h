#define WND_PARAM_X     100
#define WND_PARAM_Y     30

#define WND_PARAM_WIDTH     500
#define WND_PARAM_HEIGH     639

#define WND_PARAM_TITLE    "����˹����"

#define TIMER_ID	1
#define TIMER_INTERVAL 500

#define BACKGROUND_SIZE_WIDTH  300
#define BACKGROUND_SIZE_HEIGH  600