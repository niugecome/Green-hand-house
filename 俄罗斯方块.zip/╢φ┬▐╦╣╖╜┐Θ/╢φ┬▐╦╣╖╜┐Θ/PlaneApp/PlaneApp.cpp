#include"PlaneApp.h"
#include"../GameConfig/GameConfig.h"
#include<time.h>

GET_OBJECT(CPlaneApp)
	CLASS_CONFIG(WND_PARAM_X,WND_PARAM_Y,WND_PARAM_WIDTH,WND_PARAM_HEIGH,WND_PARAM_TITLE)


	CPlaneApp::CPlaneApp(){


}
CPlaneApp::~CPlaneApp(){


}


//case WM_CREATE: //���ڴ�����Ϣ
void CPlaneApp::OnCreate(){

	srand((unsigned int)time(NULL));
	//������ʱ��
	m_mySquare.CreateRandomSquare();
	m_mySquare.SquareToBackground();
}

//case WM_PAINT:  //�ػ���Ϣ
void CPlaneApp::OnDraw(){
	HDC hdc = ::GetDC(this->m_hWnd);
	HDC cacheDC = ::CreateCompatibleDC(hdc);
	HBITMAP map = ::CreateCompatibleBitmap(hdc,500,600);
	::SelectObject(cacheDC,map);

	m_mySquare.PrintSquare(cacheDC);
	m_mySquare.PrintChangedSquare(cacheDC);

	::BitBlt(hdc,0,0,300,600,cacheDC,0,0,SRCCOPY);
	itoa(m_mySquare.m_Socre,m_strScore,10);

	TextOut(hdc,320,10,"������ţ��",10);
	TextOut(hdc,320,40,"������",6);
	TextOut(hdc,360,40,m_strScore,strlen(m_strScore));

	::DeleteObject(map);
	map = NULL;

	ReleaseDC(this->m_hWnd,hdc);
}




//case WM_TIMER:   //��ʱ������Ҫ�������������ֶ����Ӷ�ʱ�������ô������
void CPlaneApp::OnGameRun(WPARAM wParam){

	if(m_mySquare.CanSquareDown() == 1 && m_mySquare.CanSquareDown2() == 1)
	{
		m_mySquare.SquareDown();
		m_mySquare.m_nLine++;
	}
	else
	{
		m_mySquare.ChangeSquaretype();
		m_mySquare.DesroryOneLine();
		if(m_mySquare.IfGameOver() == 0)
		{
			GameOver();
		}

		m_mySquare.CreateRandomSquare();
		m_mySquare.SquareToBackground();
	}
	CPlaneApp::OnDraw();

}

//case WM_KEYDOWN:  //���̰��´�����Ϣ
void CPlaneApp::OnKeyDown(WPARAM wParam){
	switch(wParam)
	{
	case VK_RIGHT:
			{
			if(m_mySquare.IfSquareRight() == 1 && m_mySquare.IfSquareRight2() == 1)
			{
			m_mySquare.RightMove();
			m_mySquare.m_nList++;
			OnDraw();
			}
		}

		break;
	case VK_LEFT:
		{
			if(m_mySquare.IfSquareLeft() == 1 && m_mySquare.IfSquareLeft2() == 1)
			{

			m_mySquare.LeftMove();

			m_mySquare.m_nList--;

			OnDraw();

			}
		}
		break;
	case VK_UP:
		m_mySquare.ChangeSquare();

		break;
	case VK_DOWN:
		OnGameRun(wParam);

		break;
	case VK_RETURN:
		SetTimmer();
		break;
	}
}


void CPlaneApp::SetTimmer(){
	::SetTimer(this->m_hWnd,TIMER_ID,TIMER_INTERVAL,NULL);
}


void CPlaneApp::GameOver(){


	::KillTimer(this->m_hWnd,TIMER_ID);

	// ��ʾGameOver

	::MessageBox(this->m_hWnd,"GameOver~~","��ʾ",MB_OK);


	// ���ͳ����˳���Ϣ
	PostMessage(this->m_hWnd,WM_DESTROY,0,0);

}

