#include"Square.h"
#include"../GameConfig/GameConfig.h"


CSquare::CSquare()
{
	for(int i=0;i<20;i++)
	{
		for(int j =0;j<10;j++)
		{
			m_Background[i][j] = 0;
		}
	}
	m_SquareId = -1;
	m_nLine = -1;
	m_nList = -1;
	m_Socre = 0;
	m_R = 0;
	m_G = 0;
	m_B = 0;
}
CSquare::~CSquare()
{
	for(int i=0;i<20;i++)
	{
		for(int j =0;j<10;j++)
		{
			m_Background[i][j] = 0;
		}
	}
	m_SquareId = 0;
	m_nLine = 0;
	m_nList = 0;
	m_R = 0;
	m_G = 0;
	m_B = 0;
}

void CSquare::PrintSquare(HDC cacheDC)
{


	Rectangle(cacheDC,0,0,BACKGROUND_SIZE_WIDTH,BACKGROUND_SIZE_HEIGH);
	
	m_R = rand()%255;
	m_G = rand()%255;
	m_B = rand()%255;

	HBRUSH HNewBrush = ::CreateSolidBrush(RGB(m_R,m_G,m_B));
	HBRUSH HOldBrush = (HBRUSH)::SelectObject(cacheDC,HNewBrush);

	for(int i=0;i<20;i++)
	{
		for(int j =0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				Rectangle(cacheDC,j*30,i*30,j*30+30,i*30+30);
			}
		}
	}
	HNewBrush = (HBRUSH)::SelectObject(cacheDC,HOldBrush);
	DeleteObject(HNewBrush);
}

void CSquare::CreateRandomSquare()
{
	int index = rand()%7;

	switch(index)
	{
	case 0:
		{
			m_tempSquare[0][0] = 1;m_tempSquare[0][1] = 1;m_tempSquare[0][2] = 0;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 0;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 1;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 3;
		}
		break;
	case 1:
		{
			m_tempSquare[0][0] = 0;m_tempSquare[0][1] = 1;m_tempSquare[0][2] = 1;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 1;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 0;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 3;
		}
		break;
	case 2:
		{
			m_tempSquare[0][0] = 1;m_tempSquare[0][1] = 0;m_tempSquare[0][2] = 0;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 1;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 1;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 3;
		}
		break;
	case 3:
		{
			m_tempSquare[0][0] = 0;m_tempSquare[0][1] = 0;m_tempSquare[0][2] = 1;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 1;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 1;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 3;
		}
		break;
	case 4:
		{
			m_tempSquare[0][0] = 0;m_tempSquare[0][1] = 1;m_tempSquare[0][2] = 0;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 1;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 1;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 3;
		}
		break;
	case 5:
		{
			m_tempSquare[0][0] = 0;m_tempSquare[0][1] = 1;m_tempSquare[0][2] = 1;m_tempSquare[0][3] = 0;
			m_tempSquare[1][0] = 0;m_tempSquare[1][1] = 1;m_tempSquare[1][2] = 1;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 4;
		}
		break;
	case 6:
		{
			m_tempSquare[0][0] = 1;m_tempSquare[0][1] = 1;m_tempSquare[0][2] = 1;m_tempSquare[0][3] = 1;
			m_tempSquare[1][0] = 0;m_tempSquare[1][1] = 0;m_tempSquare[1][2] = 0;m_tempSquare[1][3] = 0;
			m_nLine = 0;
			m_nList = 4;
		}
		break;
	}
	m_SquareId = index;
}

void CSquare::SquareToBackground()
{
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<4;j++)
		{
			m_Background[i][j+3] = m_tempSquare[i][j];
		}
	}

}

void CSquare::SquareDown()
{
	for(int i=19;i>=0;i--)
	{
		for(int j = 0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				m_Background[i+1][j] = m_Background[i][j];
				m_Background[i][j] = 0;
			}
		}
	}

}

int CSquare::CanSquareDown()
{
	for(int i=0;i<10;i++)
	{
		if(m_Background[19][i] == 1)
		{
			return 0;
		}
	}
	return 1;
}

void CSquare::ChangeSquaretype()
{
	for(int i=0;i<20;i++)
	{
		for(int j=0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				m_Background[i][j] = 2;
			}
		}
	}
}

void  CSquare::PrintChangedSquare(HDC cacheDC)
{
	HBRUSH HOldBrush;
	HBRUSH HNewBrush = ::CreateSolidBrush(RGB(m_R,m_G,m_B));
	HOldBrush = (HBRUSH)::SelectObject(cacheDC,HNewBrush);

	for(int i=0;i<20;i++)
	{
		for(int j =0;j<10;j++)
		{
			if(m_Background[i][j] == 2)
			{
				Rectangle(cacheDC,j*30,i*30,j*30+30,i*30+30);
			}
		}
	}
	HNewBrush = (HBRUSH)::SelectObject(cacheDC,HOldBrush);
	DeleteObject(HNewBrush);
}

int CSquare::CanSquareDown2()
{
	for(int i=19;i>=0;i--)
	{
		for(int j=0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				if(m_Background[i+1][j] == 2)
				{
					return 0;
				}
			}
		}
	}
	return  1;
}

void CSquare::LeftMove()
{
	for(int i=0;i<20;i++)
	{
		for(int j = 0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				m_Background[i][j-1] = m_Background[i][j];
				m_Background[i][j] = 0;
			}
		}
	}
}

int CSquare::IfSquareLeft()
{
	for(int i=0;i<20;i++)
	{
		if(m_Background[i][0] == 1)
		{
			return 0;
		}
	}
	return 1;
}

int CSquare::IfSquareLeft2()
{
	for(int i=0;i<20;i++)
	{
		for(int j = 0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				if(m_Background[i][j-1] == 2)
				{
					return 0;
				}
			}
		}
	}
	return 1;
}

void CSquare::RightMove()
{
	for(int i=0;i<20;i++)
	{
		for(int j = 9;j>=0;j--)
		{
			if(m_Background[i][j] == 1)
			{
				m_Background[i][j+1] = m_Background[i][j];
				m_Background[i][j] = 0;
			}
		}
	}
}

int CSquare::IfSquareRight()
{
	for(int i=0;i<20;i++)
	{
		if(m_Background[i][9] == 1)
		{
			return 0;
		}
	}
	return 1;
}

int CSquare::IfSquareRight2()
{
	for(int i=0;i<20;i++)
	{
		for(int j = 0;j<10;j++)
		{
			if(m_Background[i][j] == 1)
			{
				if(m_Background[i][j+1] == 2)
				{
					return 0;
				}
			}
		}
	}
	return 1;
}

void CSquare::ChangeSquare()
{
	switch(m_SquareId)
	{
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
		{
		if(IfChangeSquare() == 1)
		{
		GetChangeMode();
		}
		else
		{
			return ;
		}
		}
		break;
	case 5:
		return ;
		break;
	case 6:
		{
		if(IfLineChange() == 1)
		{
		ChangeLineSquare();
		}
		}
		break;
	}
}

void CSquare::GetChangeMode()
{
	char square[3][3] = {0};
	int tem = 2;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			square[i][j] = m_Background[m_nLine+i][m_nList+j];
		}
	}

	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m_Background[m_nLine+i][m_nList+j] = square[tem][i];
			tem--;
		}
		tem = 2;
	}
}

int CSquare::IfChangeSquare() 
{
	for(int i=0;i<3;i++)
	{
		for(int j = 0;j<3;j++)
		{
			if(m_Background[i+m_nLine][j+m_nList] == 2)
			{
				return 0;
			}
		}
	}
	if(m_nList < 0)
	{
		m_nList = 0;
	}
	else if(m_nList + 2 > 9)
	{
		m_nList = 7;
	}
	return 1;
}

void CSquare::ChangeLineSquare()
{
	if(m_Background[m_nLine][m_nList-1] == 1)
	{
		m_Background[m_nLine][m_nList - 1] = 0;
		m_Background[m_nLine][m_nList + 1] = 0;
		m_Background[m_nLine][m_nList + 2] = 0;

		if(m_Background[m_nLine + 1][m_nList] == 2)
		{
			m_Background[m_nLine-1][m_nList] = 1;
			m_Background[m_nLine-2][m_nList] = 1;
			m_Background[m_nLine-3][m_nList] = 1;
		}
		else if(m_Background[m_nLine + 2][m_nList] == 2)
		{
			m_Background[m_nLine+1][m_nList] = 1;
			m_Background[m_nLine-1][m_nList] = 1;
			m_Background[m_nLine-2][m_nList] = 1;
		}
		else
		{
			m_Background[m_nLine - 1][m_nList] = 1;
			m_Background[m_nLine + 1][m_nList] = 1;
			m_Background[m_nLine + 2][m_nList] = 1;
		}
	}
	else
	{		
		m_Background[m_nLine - 1][m_nList] = 0;
		m_Background[m_nLine + 1][m_nList] = 0;
		m_Background[m_nLine + 2][m_nList] = 0;
		if(m_Background[m_nLine][m_nList+1] == 2 || m_nList == 9)
		{
			m_Background[m_nLine][m_nList - 1] = 1;
			m_Background[m_nLine][m_nList - 2] = 1;
			m_Background[m_nLine][m_nList - 3] = 1;

			m_nList = m_nList - 2;
		}
		else if(m_Background[m_nLine][m_nList+2] == 2 || m_nList == 8)
		{
			m_Background[m_nLine][m_nList + 1] = 1;
			m_Background[m_nLine][m_nList - 1] = 1;
			m_Background[m_nLine][m_nList - 2] = 1;

			m_nList = m_nList - 1;
		}
		else if(m_Background[m_nLine][m_nList-1] == 2 || m_nList == 0)
		{
			m_Background[m_nLine][m_nList + 1] = 1;
			m_Background[m_nLine][m_nList + 2] = 1;
			m_Background[m_nLine][m_nList + 3] = 1;

			m_nList = m_nList + 1;
		}
		else
		{						  
		m_Background[m_nLine][m_nList - 1] = 1;
		m_Background[m_nLine][m_nList + 1] = 1;
		m_Background[m_nLine][m_nList + 2] = 1;
		}
	}
}

int CSquare::IfLineChange()
{
	int i = 0,j = 0;
	for(i=1;i<=3;i++)
	{
		if(m_Background[m_nLine][m_nList+i] == 2 || m_nList + i > 9)
		{
			break;
		}
	}
	for(j = 1;j <= 3 ; j ++)
	{
		if(m_Background[m_nLine][m_nList-j] == 2 || m_nList-j < 0)
		{
			break;
		}
	}
	if((i - 1 + j - 1) < 3)
	{
		return 0;
	}
	return 1;
}

void CSquare::DesroryOneLine()
{
	int sum = 0;
	for(int i =19;i >= 0;i--)
	{
		for(int j = 0;j<10;j++)
		{
			sum += m_Background[i][j];
		}
		if(sum == 20)
		{
			for(int k = i - 1;k >= 0;k--)
			{
				for(int q = 0;q < 10;q++)
				{
					m_Background[k+1][q] = m_Background[k][q];
				}
			}
			m_Socre ++;
			i = 20;
		}
		sum = 0;
	}
}

int CSquare::IfGameOver()
{
	for(int i=0;i<10;i++)
	{
		if(m_Background[0][i] == 2)
		{
			return 0;
		}
	}
	return 1;
}