#include<Windows.h>

class CSquare{
public:
	char m_Background[20][10];
	char m_tempSquare[2][4];
	int m_SquareId;
	int m_nLine;
	int m_nList;
	int m_Socre;
	int m_R;
	int m_G;
	int m_B;
public:
	CSquare();
	~CSquare();
public:
	void PrintSquare(HDC cacheDC);
	void CreateRandomSquare();
	void SquareToBackground();
	void SquareDown();
	int CanSquareDown();
	void ChangeSquaretype();
	void  PrintChangedSquare(HDC cacheDC);
	int CanSquareDown2();
	void LeftMove();
	int IfSquareLeft();
	int IfSquareLeft2();
	void RightMove();
	int IfSquareRight();
	int IfSquareRight2();
	void ChangeSquare();
	void GetChangeMode();
	int IfChangeSquare();
	void ChangeLineSquare();
	int IfLineChange();
	void DesroryOneLine();

	int IfGameOver();

};
